import "dotenv/config";
import express from "express";
import path from "path";
import { fileURLToPath } from "url";

import chatRouter from "./routes/chat.js";
import customersRouter from "./routes/customers.js";
import healthRouter from "./routes/health.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/chat", chatRouter);
app.use("/api/customers", customersRouter);
app.use("/api/health", healthRouter);

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`MemoryDesk running at http://localhost:${PORT}`);
});