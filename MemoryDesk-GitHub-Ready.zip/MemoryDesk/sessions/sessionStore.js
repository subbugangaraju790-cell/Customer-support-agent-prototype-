const sessions = new Map();

export function getSession(customerId) {
  if (!sessions.has(customerId)) {
    sessions.set(customerId, []);
  }

  return sessions.get(customerId);
}

export function addMessage(customerId, message) {
  const session = getSession(customerId);
  session.push(message);

  // Keep session context bounded.
  if (session.length > 20) {
    session.splice(0, session.length - 20);
  }

  return message;
}

export function resetSession(customerId) {
  sessions.set(customerId, []);
}