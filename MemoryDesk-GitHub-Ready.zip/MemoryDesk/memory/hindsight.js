const BASE_URL = (process.env.HINDSIGHT_BASE_URL || "").replace(/\/$/, "");
const API_KEY = process.env.HINDSIGHT_API_KEY || "";
const TIMEOUT = Number(process.env.HINDSIGHT_TIMEOUT_MS || 5000);

function headers() {
  return {
    "Content-Type": "application/json",
    ...(API_KEY ? { Authorization: `Bearer ${API_KEY}` } : {})
  };
}

async function request(url, options = {}) {
  if (!BASE_URL) {
    throw new Error("HINDSIGHT_BASE_URL is not configured.");
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT);

  try {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...headers(),
        ...(options.headers || {})
      },
      signal: controller.signal
    });

    const text = await response.text();
    let data = {};

    try {
      data = text ? JSON.parse(text) : {};
    } catch {
      data = { raw: text };
    }

    if (!response.ok) {
      throw new Error(`Hindsight HTTP ${response.status}`);
    }

    return data;
  } finally {
    clearTimeout(timer);
  }
}

/*
 * Hindsight deployments can expose slightly different API paths depending
 * on version/configuration. Keep all Hindsight-specific calls isolated here.
 * The rest of MemoryDesk does not depend on Hindsight's HTTP shape.
 */

export async function recallMemory(customerId, query) {
  try {
    // Common REST shape. Adjust only this module if your Hindsight deployment
    // uses different endpoint names.
    const data = await request(
      `${BASE_URL}/v1/memories/${encodeURIComponent(customerId)}/recall`,
      {
        method: "POST",
        body: JSON.stringify({ query, limit: 5 })
      }
    );

    const raw = data.memories || data.results || data.items || [];

    return {
      available: true,
      memories: raw.map((item) => ({
        text: item.text || item.content || item.memory || JSON.stringify(item),
        relevance: Number(item.relevance ?? item.score ?? 0)
      }))
    };
  } catch (error) {
    console.warn("Hindsight recall unavailable:", error.message);
    return {
      available: false,
      memories: []
    };
  }
}

export async function retainMemory(customerId, payload) {
  const data = {
    ...payload,
    customerId,
    timestamp: new Date().toISOString()
  };

  // MemoryDesk does not block the user response on this call.
  await request(
    `${BASE_URL}/v1/memories/${encodeURIComponent(customerId)}/retain`,
    {
      method: "POST",
      body: JSON.stringify(data)
    }
  );

  return { success: true };
}

export async function getMemoryCount(customerId) {
  try {
    const data = await request(
      `${BASE_URL}/v1/memories/${encodeURIComponent(customerId)}`,
      { method: "GET" }
    );

    if (typeof data.count === "number") return data.count;
    if (Array.isArray(data.memories)) return data.memories.length;
    if (Array.isArray(data.items)) return data.items.length;

    return 0;
  } catch {
    return 0;
  }
}

export async function hindsightHealth() {
  try {
    await request(`${BASE_URL}/health`, { method: "GET" });
    return {
      available: true,
      status: "healthy"
    };
  } catch (error) {
    return {
      available: false,
      status: "unavailable",
      message: error.message
    };
  }
}