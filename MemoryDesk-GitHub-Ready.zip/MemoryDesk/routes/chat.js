import { Router } from "express";
import { getCustomer } from "../models/customer.js";
import { getSession, addMessage, resetSession } from "../sessions/sessionStore.js";
import { recallMemory, retainMemory, getMemoryCount } from "../memory/hindsight.js";
import { generateSupportResponse } from "../llm/groq.js";

const router = Router();

router.post("/", async (req, res) => {
  try {
    const {
      customerId,
      message,
      memoryEnabled = true
    } = req.body;

    if (!customerId || !message?.trim()) {
      return res.status(400).json({
        error: "customerId and message are required."
      });
    }

    const customer = getCustomer(customerId);

    if (!customer) {
      return res.status(404).json({
        error: "Customer not found."
      });
    }

    const session = getSession(customerId);

    const userMessage = {
      role: "user",
      content: message.trim(),
      timestamp: new Date().toISOString()
    };

    addMessage(customerId, userMessage);

    let memories = [];
    let memoryStatus = memoryEnabled ? "pending" : "disabled";

    if (memoryEnabled) {
      const result = await recallMemory(customerId, message.trim());
      memories = result.memories;
      memoryStatus = result.available ? "available" : "unavailable";
    }

    const response = await generateSupportResponse({
      customer,
      sessionHistory: getSession(customerId),
      memories,
      currentMessage: message.trim()
    });

    const assistantMessage = {
      role: "assistant",
      content: response,
      timestamp: new Date().toISOString()
    };

    addMessage(customerId, assistantMessage);

    if (memoryEnabled) {
      // Retention intentionally happens asynchronously.
      retainMemory(customerId, {
        customerMessage: message.trim(),
        agentResponse: response
      }).catch((error) => {
        console.warn("Background Hindsight retain failed:", error.message);
      });
    }

    const memoryCount = await getMemoryCount(customerId);

    res.json({
      response,
      memories,
      memoryEnabled,
      memoryStatus,
      memoryCount,
      trace: [
        "Customer message",
        memoryEnabled ? "Hindsight recall" : "Memory disabled",
        memoryEnabled ? `${memories.length} relevant memories` : "Session context only",
        "Groq LLM",
        "Response generated",
        memoryEnabled ? "Hindsight retain queued" : "No memory retained"
      ],
      session: getSession(customerId)
    });
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({
      error: error.message || "Unable to generate response."
    });
  }
});

router.post("/reset", (req, res) => {
  const { customerId } = req.body;

  if (!customerId) {
    return res.status(400).json({ error: "customerId is required." });
  }

  resetSession(customerId);

  res.json({
    success: true,
    message: "Current session reset."
  });
});

export default router;