import { Router } from "express";
import { customers } from "../models/customer.js";
import { getMemoryCount } from "../memory/hindsight.js";

const router = Router();

router.get("/", async (req, res) => {
  const result = await Promise.all(
    customers.map(async (customer) => ({
      ...customer,
      memoryCount: await getMemoryCount(customer.id)
    }))
  );

  res.json({ customers: result });
});

export default router;