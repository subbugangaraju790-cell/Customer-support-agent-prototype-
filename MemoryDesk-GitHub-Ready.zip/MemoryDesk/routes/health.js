import { Router } from "express";
import { hindsightHealth } from "../memory/hindsight.js";

const router = Router();

router.get("/", async (req, res) => {
  const memory = await hindsightHealth();

  res.json({
    status: "ok",
    application: "healthy",
    hindsight: memory
  });
});

export default router;