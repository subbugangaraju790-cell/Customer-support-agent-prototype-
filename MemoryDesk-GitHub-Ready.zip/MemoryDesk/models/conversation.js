export function createMessage(role, content) {
  return {
    role,
    content,
    timestamp: new Date().toISOString()
  };
}