export const customers = [
  {
    id: "customer_001",
    name: "Ananya Rao",
    company: "Acme Technologies",
    email: "ananya@example.com",
    environment: "Node.js production API",
    plan: "Enterprise"
  },
  {
    id: "customer_002",
    name: "Rahul Mehta",
    company: "Nova Retail",
    email: "rahul@example.com",
    environment: "React + cloud deployment",
    plan: "Business"
  },
  {
    id: "customer_003",
    name: "Priya Sharma",
    company: "Orbit Finance",
    email: "priya@example.com",
    environment: "Python backend",
    plan: "Enterprise"
  }
];

export function getCustomer(id) {
  return customers.find((customer) => customer.id === id);
}