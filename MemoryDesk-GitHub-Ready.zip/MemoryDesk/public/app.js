let selectedCustomer = null;

const customersEl = document.getElementById("customers");
const messagesEl = document.getElementById("messages");
const messageInput = document.getElementById("messageInput");
const sendBtn = document.getElementById("sendBtn");
const resetBtn = document.getElementById("resetBtn");
const memoryToggle = document.getElementById("memoryToggle");
const memoryCount = document.getElementById("memoryCount");
const memoriesEl = document.getElementById("memories");
const traceEl = document.getElementById("trace");
const healthEl = document.getElementById("health");
const customerName = document.getElementById("customerName");
const customerMeta = document.getElementById("customerMeta");

async function loadCustomers() {
  const response = await fetch("/api/customers");
  const data = await response.json();

  customersEl.innerHTML = "";

  data.customers.forEach((customer) => {
    const item = document.createElement("div");
    item.className = "customer";
    item.dataset.id = customer.id;

    item.innerHTML = `
      <div class="customer-name">${escapeHtml(customer.name)}</div>
      <div class="customer-company">${escapeHtml(customer.company)}</div>
    `;

    item.onclick = () => selectCustomer(customer);
    customersEl.appendChild(item);
  });
}

function selectCustomer(customer) {
  selectedCustomer = customer;

  document.querySelectorAll(".customer").forEach((item) => {
    item.classList.toggle("active", item.dataset.id === customer.id);
  });

  customerName.textContent = customer.name;
  customerMeta.textContent =
    `${customer.company} · ${customer.environment} · ${customer.plan}`;

  memoryCount.textContent = customer.memoryCount || 0;

  messagesEl.innerHTML = `
    <div class="empty-state">
      New session for ${escapeHtml(customer.name)}.
    </div>
  `;

  memoriesEl.innerHTML = `<div class="muted">No memories retrieved yet.</div>`;
  traceEl.innerHTML = "";
}

async function sendMessage() {
  if (!selectedCustomer) {
    alert("Select a customer first.");
    return;
  }

  const message = messageInput.value.trim();

  if (!message) return;

  sendBtn.disabled = true;
  sendBtn.textContent = "Thinking...";

  appendMessage("user", message);
  messageInput.value = "";

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        customerId: selectedCustomer.id,
        message,
        memoryEnabled: memoryToggle.checked
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    appendMessage("assistant", data.response);
    renderMemories(data.memories);
    renderTrace(data.trace);

    memoryCount.textContent = data.memoryCount ?? 0;

    if (data.memoryStatus === "unavailable") {
      memoriesEl.insertAdjacentHTML(
        "afterbegin",
        `<div class="muted" style="margin-bottom:10px">Memory unavailable — response used session context.</div>`
      );
    }
  } catch (error) {
    appendMessage("assistant", `Error: ${error.message}`);
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = "Send";
  }
}

function appendMessage(role, content) {
  const empty = messagesEl.querySelector(".empty-state");
  if (empty) empty.remove();

  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;

  wrapper.innerHTML = `
    <div class="message-label">${role === "user" ? "Customer" : "MemoryDesk AI"}</div>
    <div class="bubble">${escapeHtml(content)}</div>
  `;

  messagesEl.appendChild(wrapper);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderMemories(memories) {
  if (!memories?.length) {
    memoriesEl.innerHTML =
      `<div class="muted">No relevant long-term memories found.</div>`;
    return;
  }

  memoriesEl.innerHTML = memories
    .map(
      (memory) => `
        <div class="memory-card">
          ${escapeHtml(memory.text)}
          <div class="relevance">
            Relevance: ${
              typeof memory.relevance === "number"
                ? memory.relevance.toFixed(2)
                : "n/a"
            }
          </div>
        </div>
      `
    )
    .join("");
}

function renderTrace(trace) {
  traceEl.innerHTML = trace
    .map(
      (step) =>
        `<div class="trace-step done">✓ ${escapeHtml(step)}</div>`
    )
    .join("");
}

async function resetSession() {
  if (!selectedCustomer) return;

  await fetch("/api/chat/reset", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      customerId: selectedCustomer.id
    })
  });

  messagesEl.innerHTML = `
    <div class="empty-state">
      Session reset. Long-term customer memory was not deleted.
    </div>
  `;

  memoriesEl.innerHTML =
    `<div class="muted">No memories retrieved yet.</div>`;
  traceEl.innerHTML = "";
}

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();

    if (data.hindsight?.available) {
      healthEl.innerHTML =
        `<span class="status-dot"></span> System Healthy · Memory Online`;
    } else {
      healthEl.innerHTML =
        `<span class="status-dot"></span> App Healthy · Memory Offline`;
    }
  } catch {
    healthEl.innerHTML =
      `<span class="status-dot" style="background:#ff7181"></span> Server Offline`;
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

sendBtn.addEventListener("click", sendMessage);
resetBtn.addEventListener("click", resetSession);

messageInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});

memoryToggle.addEventListener("change", () => {
  memoryToggle.parentElement.lastElementChild.textContent =
    memoryToggle.checked ? "Memory ON" : "Memory OFF";
});

loadCustomers();
checkHealth();
setInterval(checkHealth, 30000);